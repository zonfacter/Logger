"""
HausBus Plugin for RS485 Sniffer
"""
from .hausbus_plugin import HausBusPlugin

__all__ = ['HausBusPlugin']
