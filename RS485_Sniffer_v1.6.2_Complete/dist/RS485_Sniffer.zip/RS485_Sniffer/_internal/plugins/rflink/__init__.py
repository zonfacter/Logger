"""
RFLink Plugin for RS485 Sniffer
"""
from .rflink_plugin import RFLinkPlugin

__all__ = ['RFLinkPlugin']
